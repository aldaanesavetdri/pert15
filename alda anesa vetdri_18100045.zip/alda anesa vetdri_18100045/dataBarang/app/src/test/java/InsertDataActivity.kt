package com.informatika

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.inputmethod.BaseInputConnection
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class InsertDataActivity : AppCompatActivity ()
@SuppressLint( "RestrictedApi")
override fun onCreate(savedInstanceState: Bundle?) {
    seper.onCreate(savedInstanceState)
    setContentView(R.layout.activity_insert_data)
    toolbar.title = "INSERT DATA"
    toolbar.setTitleTexColor(color.WHITE)

    btn_submit.setOnClickListener {
        val etNamaBarang = et_nama_barang.text
        val etJmlBarang = et_jumlah_barang.text
        if (etjmlbarang.isEmpty()) {
            Toast.makeText(
                this@InsertDataActivity,
                "Jumlah Barang tidak Boleh Kosong",
                Toast.LENGTH_LONG
            ).show()
        } else if (etJmlBarang.isEmpty()) {
            Toast.makeText(
                this@InsertDataActivity, "Nama Barang tidak Boleh kosong", Toast.LENGTH_LONG
            ).show()
        } else
            actionData(etNamaBarang.toString(), etJmlBarang.toString())
    }
}

btn_clean.setOnClickListener {
    formClear()
}
getData()

}
fun formClear(){
    et_nama_barang.text.clear()
    et_jumlah_barang.text.clear()

}

      